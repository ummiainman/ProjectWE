<?php
// login.php
session_start();

$servername = "localhost";
$username = "root"; // replace with your database username
$password = ""; // replace with your database password
$dbname = "FKParkDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inputUsername = $_POST['username'];
    $inputPassword = $_POST['password'];
    $inputRole = $_POST['role'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $inputUsername);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $username, $hashed_password, $role);
    $stmt->fetch();

    if ($stmt->num_rows > 0) {
        // Verify password
        if (password_verify($inputPassword, $hashed_password) && $inputRole == $role) {
            // Start a session and store user info
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;
			
			header("Location: /login/login/module1/admin_dashboard.html");
            // Redirect to the appropriate dashboard
            // header("Location: dashboard.php");
        } else {
            echo "Invalid password or role.";
        }
    } else {
        echo "No user found with the username: $inputUsername";
    }

    $stmt->close();
}

$conn->close();
?>
