// login.js
function validateLoginForm() {
    const username = document.forms["loginForm"]["username"].value;
    const password = document.forms["loginForm"]["password"].value;
    const role = document.forms["loginForm"]["role"].value;

    if (username == "" || password == "" || role == "") {
        alert("All fields must be filled out");
        return false;
    }

    // Additional validation can be added here

    return true;
}
