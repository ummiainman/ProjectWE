function validateRegistrationForm() {
    var username = document.forms["registrationForm"]["username"].value;
    var email = document.forms["registrationForm"]["email"].value;
    var password = document.forms["registrationForm"]["password"].value;
    var role = document.forms["registrationForm"]["role"].value;

    if (username == "" || email == "" || password == "" || role == "") {
        alert("All fields must be filled out");
        return false;
    }

    // Add additional validation rules if needed

    return true;
}
